//
//  Segitiga.h
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#ifndef Segitiga_h
#define Segitiga_h
#include "BangunDatar.h"

#endif /* Segitiga_h */
class Segitiga:public BangunDatar{
public:
    Segitiga();
    Segitiga(int,int,int);
    float Luas();
    float Keliling();
private:
    int a;
    int t;
    int s;
};
