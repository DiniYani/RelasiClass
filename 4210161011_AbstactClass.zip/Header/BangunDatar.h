//
//  BangunDatar.h
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#ifndef BangunDatar_h
#define BangunDatar_h
#endif /* BangunDatar_h */

class BangunDatar{
public:

    virtual float Luas() = 0;
    virtual float Keliling() = 0;

};
