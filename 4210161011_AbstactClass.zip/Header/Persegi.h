//
//  Persegi.h
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#ifndef Persegi_h
#define Persegi_h
#include "BangunDatar.h"

#endif /* Persegi_h */
class Persegi:public BangunDatar{
public:
    Persegi();
    Persegi(int,int);
    float Luas();
    float Keliling();
private:
    int p;
    int l;
};
