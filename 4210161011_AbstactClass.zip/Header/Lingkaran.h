//
//  Lingkaran.h
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#ifndef Lingkaran_h
#define Lingkaran_h
#include "BangunDatar.h"

#endif /* Lingkaran_h */
class Lingkaran : public BangunDatar{
public:
    Lingkaran();
    Lingkaran(int);
    float Luas();
    float Keliling();
private:
    float r;
    
    
};

