//
//  Lingkaran.cpp
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#include "Lingkaran.h"
Lingkaran::Lingkaran(){
    r=7;
}
Lingkaran::Lingkaran(int r){
    this->r=r;
}

float Lingkaran::Luas() {
    return 3.14 * r * r;
}

float Lingkaran::Keliling() {
    return 3.14*2*r;
}
