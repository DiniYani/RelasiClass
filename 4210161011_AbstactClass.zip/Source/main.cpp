//
//  main.cpp
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#include <iostream>
using namespace std;
#include "Lingkaran.h"
#include "Persegi.h"
#include "Segitiga.h"

int main()
{
    Lingkaran link(10);
    link.Luas();
    link.Keliling();
    cout<< "Luas Lingkaran:\t"<<link.Luas()<<endl;
    cout<< "Keliling Lingkaran:\t"<<link.Keliling()<<endl;
    Persegi pers(10,10);
    pers.Luas();
    pers.Keliling();
    cout<< "Luas Persegi:\t"<<pers.Luas()<<endl;
    cout<< "Keliling Persegi:\t"<<pers.Keliling()<<endl;
    Segitiga seg(10,10,10);
    seg.Luas();
    seg.Keliling();
    cout<< "Luas Segitiga:\t"<<seg.Luas()<<endl;
    cout<< "Keliling Segitiga:\t"<<seg.Keliling()<<endl;
}


