//
//  Persegi.cpp
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#include "Persegi.h"
Persegi::Persegi(){
    p=7;
    l=7;
}
Persegi::Persegi(int p,int l){
    this->l=l;
    this->p=p;
}

float Persegi::Luas(){
    return p*l;
}
float Persegi::Keliling(){
    return 2*p+2*l;
}
