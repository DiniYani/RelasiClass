//
//  Segitiga.cpp
//  AbstractClass
//
//  Created by dini yani on 3/27/18.
//  Copyright © 2018 dini yani. All rights reserved.
//

#include "Segitiga.h"
Segitiga::Segitiga(){
    a=7;
    t=6;
    s=5;
}
Segitiga::Segitiga(int a,int t, int s){
    this->a=a;
    this->t=t;
    this->s=s;
}
float Segitiga::Luas(){
    return 0.5*a*t;
}
float Segitiga::Keliling(){
    return 3*s;
}
